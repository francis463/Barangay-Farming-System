
  # Barangay Farming System

  This is a code bundle for Barangay Farming System. The original project is available at https://www.figma.com/design/yqixT42wXOxldneC9R4Sa1/Barangay-Farming-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  