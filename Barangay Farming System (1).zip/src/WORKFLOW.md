# 🔄 Plant n' Plan - System Workflow Documentation

This document provides a comprehensive overview of how the Plant n' Plan Barangay Community Farming System works, including user flows, data flows, and technical architecture.

## 📋 Table of Contents

- [System Architecture](#system-architecture)
- [Authentication Flow](#authentication-flow)
- [User Workflows](#user-workflows)
- [Admin Workflows](#admin-workflows)
- [Data Flow Architecture](#data-flow-architecture)
- [Feature Workflows](#feature-workflows)
- [API Request/Response Flow](#api-requestresponse-flow)
- [State Management](#state-management)
- [Error Handling](#error-handling)

---

## 🏗️ System Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     CLIENT (React + TypeScript)              │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐            │
│  │  App.tsx   │  │ Components │  │   Utils    │            │
│  │  (Router)  │  │   (UI)     │  │ (Helpers)  │            │
│  └─────┬──────┘  └─────┬──────┘  └─────┬──────┘            │
│        │               │               │                     │
│        └───────────────┴───────────────┘                     │
│                        │                                     │
└────────────────────────┼─────────────────────────────────────┘
                         │ HTTPS/REST API
                         ▼
┌─────────────────────────────────────────────────────────────┐
│              SUPABASE BACKEND (Edge Functions)              │
│  ┌─────────────────────────────────────────────────────┐   │
│  │           Hono Web Server (Deno Runtime)             │   │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐          │   │
│  │  │  Routes  │  │   Auth   │  │ Storage  │          │   │
│  │  │ Handlers │  │  Verify  │  │ Handler  │          │   │
│  │  └────┬─────┘  └────┬─────┘  └────┬─────┘          │   │
│  └───────┼─────────────┼─────────────┼────────────────┘   │
│          │             │             │                     │
│          ▼             ▼             ▼                     │
│  ┌─────────────┐  ┌─────────┐  ┌──────────┐              │
│  │  KV Store   │  │  Auth   │  │ Storage  │              │
│  │ (Postgres)  │  │ Service │  │ Buckets  │              │
│  └─────────────┘  └─────────┘  └──────────┘              │
└─────────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                   EXTERNAL SERVICES                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │ OpenWeather  │  │ IP Geoloc    │  │   Unsplash   │     │
│  │     API      │  │     API      │  │     API      │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
└─────────────────────────────────────────────────────────────┘
```

### Technology Stack Layers

```
┌─────────────────────────────────────────┐
│         PRESENTATION LAYER              │
│  React Components + Tailwind CSS        │
│  shadcn/ui + Lucide Icons               │
└─────────────────┬───────────────────────┘
                  │
┌─────────────────▼───────────────────────┐
│         APPLICATION LAYER               │
│  State Management (useState/useEffect)  │
│  API Client (utils/api.ts)              │
│  Auth Management (utils/auth.ts)        │
└─────────────────┬───────────────────────┘
                  │
┌─────────────────▼───────────────────────┐
│           API LAYER                     │
│  Hono Web Server (Edge Functions)      │
│  CORS + Logging + Error Handling        │
└─────────────────┬───────────────────────┘
                  │
┌─────────────────▼───────────────────────┐
│         DATA LAYER                      │
│  Supabase PostgreSQL (KV Store)        │
│  Supabase Auth + Storage                │
└─────────────────────────────────────────┘
```

---

## 🔐 Authentication Flow

### 1. User Registration Flow

```
┌─────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐
│ User    │     │ Frontend │     │  Server  │     │ Supabase │
└────┬────┘     └────┬─────┘     └────┬─────┘     └────┬─────┘
     │               │                │                 │
     │ 1. Click     │                │                 │
     │  "Sign Up"   │                │                 │
     ├──────────────>│                │                 │
     │               │                │                 │
     │ 2. Fill Form │                │                 │
     │  (Name,Email,│                │                 │
     │   Password)  │                │                 │
     ├──────────────>│                │                 │
     │               │                │                 │
     │               │ 3. POST        │                 │
     │               │  /signup       │                 │
     │               ├───────────────>│                 │
     │               │                │                 │
     │               │                │ 4. Create User  │
     │               │                │  (admin.        │
     │               │                │   createUser)   │
     │               │                ├────────────────>│
     │               │                │                 │
     │               │                │ 5. User Created │
     │               │                │  (email_confirm │
     │               │                │   = true)       │
     │               │                │<────────────────┤
     │               │                │                 │
     │               │                │ 6. Create       │
     │               │                │  Profile in KV  │
     │               │                ├─────────┐       │
     │               │                │         │       │
     │               │                │<────────┘       │
     │               │                │                 │
     │               │ 7. Success     │                 │
     │               │  Response      │                 │
     │               │<───────────────┤                 │
     │               │                │                 │
     │ 8. Show       │                │                 │
     │  Success &    │                │                 │
     │  Redirect     │                │                 │
     │<──────────────┤                │                 │
     │               │                │                 │
```

**Step-by-Step Registration Process:**

1. **User Initiates**: User clicks "Sign Up" button on landing page
2. **Form Submission**: User fills in name, email, and password
3. **Client Validation**: Frontend validates input (email format, password strength)
4. **API Request**: Frontend sends POST request to `/signup` endpoint
5. **Server Processing**: Server receives request and validates data
6. **User Creation**: Server calls `supabase.auth.admin.createUser()`
   - Email is auto-confirmed (email_confirm: true)
   - User metadata includes name
7. **Profile Creation**: Server creates user profile in KV store with:
   - User ID
   - Name, email, role
   - Default values for bio, location, stats
   - Admin check: If email is francisjohngorres@gmail.com, role = "admin"
8. **Response**: Server returns success with user data
9. **UI Update**: Frontend shows success toast and redirects to login

### 2. User Login Flow

```
┌─────────┐     ┌──────────┐     ┌──────────┐
│ User    │     │ Frontend │     │ Supabase │
└────┬────┘     └────┬─────┘     └────┬─────┘
     │               │                │
     │ 1. Enter     │                │
     │  Credentials │                │
     ├──────────────>│                │
     │               │                │
     │               │ 2. signInWith  │
     │               │   Password()   │
     │               ├───────────────>│
     │               │                │
     │               │ 3. Validate &  │
     │               │   Return       │
     │               │   Access Token │
     │               │<───────────────┤
     │               │                │
     │               │ 4. Store Token │
     │               │   in State     │
     │               ├─────────┐      │
     │               │         │      │
     │               │<────────┘      │
     │               │                │
     │               │ 5. Fetch User  │
     │               │   Profile      │
     │               ├───────────────>│
     │               │                │
     │               │ 6. Profile     │
     │               │   Data         │
     │               │<───────────────┤
     │               │                │
     │ 7. Redirect  │                │
     │   to         │                │
     │   Dashboard  │                │
     │<──────────────┤                │
     │               │                │
```

**Login Process Details:**

1. User enters email and password
2. Frontend calls `supabase.auth.signInWithPassword()`
3. Supabase validates credentials
4. If valid, returns access token and session
5. Frontend stores token in component state
6. Frontend fetches user profile from server using token
7. User is redirected to dashboard
8. Session persists in localStorage for auto-login

### 3. Session Management Flow

```
App Mount
    │
    ▼
┌─────────────────────┐
│ Check for Session   │
│ (getSession())      │
└──────────┬──────────┘
           │
    ┌──────▼──────┐
    │ Session?    │
    └──────┬──────┘
           │
    ┌──────┴──────┐
    │             │
    ▼             ▼
  Yes           No
    │             │
    │             ▼
    │      ┌─────────────┐
    │      │ Show        │
    │      │ Landing     │
    │      │ Page        │
    │      └─────────────┘
    │
    ▼
┌─────────────────────┐
│ Get Access Token    │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Fetch User Profile  │
│ from Server         │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Set Authenticated   │
│ State = true        │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Load App Data       │
│ (Crops, Budget,     │
│  Volunteers, etc.)  │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Show Dashboard      │
└─────────────────────┘
```

---

## 👥 User Workflows

### 1. Member Dashboard Access

```
Login Success
    │
    ▼
┌─────────────────────┐
│ Dashboard Loads     │
│ with Overview       │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────────────────────┐
│ Display Key Metrics:                │
│ • Total Crops                       │
│ • Active Plots                      │
│ • Upcoming Harvests                 │
│ • Budget Status                     │
└──────────┬──────────────────────────┘
           │
           ▼
┌─────────────────────────────────────┐
│ Show Recent Activity:               │
│ • Community Updates (latest 3)      │
│ • Weather Widget                    │
│ • Quick Stats Cards                 │
└─────────────────────────────────────┘
```

### 2. Crop Management Workflow

```
User Clicks "Crops"
    │
    ▼
┌─────────────────────┐
│ Load Crops from API │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Display Crops Table with:       │
│ • Crop Name, Type, Plot         │
│ • Planting Date                 │
│ • Health Status (Visual Badge)  │
│ • Harvest Status                │
│ • Action Buttons                │
└──────────┬──────────────────────┘
           │
    ┌──────┴──────┐
    │  User Can:  │
    └──────┬──────┘
           │
    ┌──────┴───────────────────┐
    │                          │
    ▼                          ▼
┌──────────┐           ┌──────────────┐
│ Add Crop │           │ Edit Crop    │
└────┬─────┘           └──────┬───────┘
     │                        │
     ▼                        ▼
┌──────────────────┐   ┌──────────────────┐
│ Fill Form:       │   │ Update Form:     │
│ • Name           │   │ • Change Status  │
│ • Type           │   │ • Update Health  │
│ • Plot #         │   │ • Modify Notes   │
│ • Planting Date  │   └────────┬─────────┘
│ • Health Status  │            │
└────┬─────────────┘            │
     │                          │
     ▼                          ▼
┌─────────────────────────────────┐
│ POST/PUT to API                 │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Server Validates & Saves        │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Return Updated Data             │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Update UI with New Data         │
│ Show Success Toast              │
└─────────────────────────────────┘
```

**Add Crop Process:**

1. User clicks "Add Crop" button
2. Dialog/Form opens with fields
3. User fills in:
   - Crop name (required)
   - Crop type: Vegetable/Fruit/Herb/Root Crop
   - Plot number
   - Planting date
   - Expected harvest date
   - Health status: Healthy/Needs Attention/Critical
4. Frontend validates input
5. POST request to `/crops` with data
6. Server creates crop with unique ID
7. Server stores in KV store under "crops:list"
8. Success response returned
9. Frontend updates local state
10. Table refreshes with new crop
11. Success toast displayed

### 3. Harvest Recording Workflow

```
User Navigates to "Harvest Tracker"
    │
    ▼
┌─────────────────────┐
│ Load Harvests & Crops│
└──────────┬───────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Display Harvest Records         │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ User Clicks "Record Harvest"    │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Select Crop (Dropdown)          │
│ • Shows only "Ready" crops      │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Enter Harvest Details:          │
│ • Harvest Date                  │
│ • Amount (kg)                   │
│ • Quality (Excellent/Good/      │
│   Fair/Poor)                    │
│ • Distribution (Sold/           │
│   Distributed/Stored)           │
│ • Price per kg (if sold)        │
│ • Notes                         │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Submit Harvest Record           │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ API: POST /harvests             │
│ Server:                         │
│ 1. Create harvest record        │
│ 2. Update crop status to        │
│    "harvested"                  │
│ 3. Calculate total value        │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Update Dashboard Metrics        │
│ Show Harvest History            │
└─────────────────────────────────┘
```

### 4. Budget Viewing Workflow

```
User Clicks "Budget"
    │
    ▼
┌─────────────────────┐
│ Load Budget Data    │
│ • Items             │
│ • Total Budget      │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Calculate:                      │
│ • Total Spent                   │
│ • Remaining Budget              │
│ • Percentage Used               │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Display:                        │
│ 1. Budget Overview Cards        │
│    • Total Budget               │
│    • Amount Spent               │
│    • Remaining                  │
│                                 │
│ 2. Progress Bar                 │
│    • Visual spend tracker       │
│                                 │
│ 3. Expense List                 │
│    • Category                   │
│    • Description                │
│    • Amount                     │
│    • Date                       │
│                                 │
│ 4. Category Breakdown Chart     │
│    • Pie/Bar chart              │
└─────────────────────────────────┘
```

**Complete Transparency:** All users can see all budget information, promoting community trust and accountability.

### 5. Community Poll Voting

```
User Navigates to "Community"
    │
    ▼
┌─────────────────────┐
│ Load Active Polls   │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Display Polls:                  │
│ • Poll Question                 │
│ • Options                       │
│ • Current Vote Counts           │
│ • Visual Chart                  │
│ • End Date                      │
│ • Vote Button (if not voted)    │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ User Selects Option & Votes     │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ POST /polls/:id/vote            │
│ Send:                           │
│ • Poll ID                       │
│ • Selected Option               │
│ • User ID                       │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Server:                         │
│ 1. Check if user already voted  │
│ 2. If not, increment vote count │
│ 3. Record user's vote           │
│ 4. Return updated poll data     │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Update UI:                      │
│ • Show updated vote counts      │
│ • Disable voting button         │
│ • Highlight user's choice       │
│ • Update chart                  │
└─────────────────────────────────┘
```

### 6. Profile Picture Upload

```
User Clicks Profile → Hovers Avatar
    │
    ▼
┌─────────────────────────────────┐
│ Camera Icon Appears             │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ User Clicks Camera Icon         │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ File Picker Opens               │
│ (Accept: image/*)               │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ User Selects Image              │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Frontend Validation:            │
│ • Check file type (image)       │
│ • Check size (< 2MB)            │
└──────────┬──────────────────────┘
           │
    ┌──────┴──────┐
    │ Valid?      │
    └──────┬──────┘
           │
      ┌────┴────┐
      │         │
     Yes       No
      │         │
      │         ▼
      │    ┌──────────┐
      │    │ Show     │
      │    │ Error    │
      │    └──────────┘
      │
      ▼
┌─────────────────────────────────┐
│ Convert to Base64               │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ POST /profile/avatar            │
│ Send: imageData, fileType       │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Server:                         │
│ 1. Create storage bucket        │
│    (if not exists)              │
│ 2. Convert base64 to binary     │
│ 3. Delete old avatar            │
│ 4. Upload new avatar            │
│ 5. Get public URL               │
│ 6. Update user profile          │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Return Avatar URL               │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Update UI:                      │
│ • Avatar displays new image     │
│ • Update header avatar          │
│ • Show success message          │
└─────────────────────────────────┘
```

---

## 👨‍💼 Admin Workflows

### 1. User Management

```
Admin Logs In
    │
    ▼
┌─────────────────────────────────┐
│ Admin Badge & Icons Visible     │
│ • Golden avatar border          │
│ • Shield icon                   │
│ • "Admin" badge                 │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ "User Management" Tab Visible   │
│ (Only for admins)               │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Admin Clicks "User Management"  │
└─────────���┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Load All Users from Server      │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Display User Table:             │
│ • Name, Email                   │
│ • Role (with badges)            │
│ • Join Date                     │
│ • Statistics                    │
│ • Action Buttons                │
└──────────┬──────────────────────┘
           │
    ┌──────┴──────┐
    │ Admin Can:  │
    └──────┬──────┘
           │
    ┌──────┴─────────────┐
    │                    │
    ▼                    ▼
┌─────────────┐    ┌──────────────┐
│ Change Role │    │ View Details │
└─────┬───────┘    └──────┬───────┘
      │                   │
      ▼                   ▼
┌──────────────────────────────────┐
│ Update in database               │
│ Show confirmation                │
└──────────────────────────────────┘
```

### 2. Poll Creation (Admin Only)

```
Admin in Community Section
    │
    ▼
┌─────────────────────────────────┐
│ "Create Poll" Button Visible    │
│ (Only for admin)                │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Admin Clicks "Create Poll"      │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Poll Creation Dialog Opens      │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Admin Fills Form:               │
│ • Poll Question (required)      │
│ • Option 1 (required)           │
│ • Option 2 (required)           │
│ • Option 3+ (optional)          │
│ • End Date (required)           │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Add/Remove Options Dynamically  │
│ (Min 2, Max 10 options)         │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Validation:                     │
│ • Question not empty            │
│ • At least 2 options            │
│ • End date is future            │
│ • No duplicate options          │
└──────────┬──────────────────────┘
           │
    ┌──────┴──────┐
    │ Valid?      │
    └──────┬──────┘
           │
      ┌────┴────┐
      │         │
     Yes       No
      │         │
      │         ▼
      │    ┌──────────┐
      │    │ Show     │
      │    │ Errors   │
      │    └──────────┘
      │
      ▼
┌─────────────────────────────────┐
│ POST /polls                     │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Server:                         │
│ 1. Verify admin role            │
│ 2. Create poll object           │
│ 3. Initialize vote counts (0)   │
│ 4. Save to database             │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Poll Appears in Community       │
│ All Users Can Vote              │
└─────────────────────────────────┘
```

### 3. System Data Management

```
Admin Functions Available
    │
    ├─────────────────────┬─────────────────────┐
    │                     │                     │
    ▼                     ▼                     ▼
┌──────────┐      ┌──────────┐         ┌──────────┐
│ Delete   │      │ Modify   │         │ Export   │
│ Any Data │      │ Settings │         │ All Data │
└────┬─────┘      └────┬─────┘         └────┬─────┘
     │                 │                     │
     ▼                 ▼                     ▼
All admin actions are logged and traceable
```

---

## 📊 Data Flow Architecture

### Complete Request/Response Cycle

```
┌──────────────────────────────────────────────────────────────┐
│                        FRONTEND                              │
└───────────────────────┬──────────────────────────────────────┘
                        │
                        │ 1. User Action (e.g., Add Crop)
                        │
                        ▼
┌─────────────────────────────────────────────────────────────┐
│              FRONTEND: Component Event Handler               │
│  • Validate input                                           │
│  • Prepare request payload                                  │
│  • Call API function from utils/api.ts                      │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ 2. HTTP Request
                        │    Method: POST/GET/PUT/DELETE
                        │    Headers: Content-Type, Authorization
                        │    Body: JSON data
                        │
                        ▼
┌─────────────────────────────────────────────────────────────┐
│              API CLIENT (utils/api.ts)                       │
│  • Add base URL                                             │
│  • Add authentication token                                 │
│  • Set headers                                              │
│  • Send fetch request                                       │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ 3. HTTPS Request
                        │
                        ▼
┌─────────────────────────────────────────────────────────────┐
│         SUPABASE EDGE FUNCTION (Hono Server)                │
│  • Receive request                                          │
│  • Apply CORS                                               │
│  • Log request                                              │
│  • Route to handler                                         │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ 4. Route Handler
                        │
                        ▼
┌─────────────────────────────────────────────────────────────┐
│              AUTHENTICATION CHECK                            │
│  • Extract Bearer token                                     │
│  • Call supabase.auth.getUser(token)                        │
│  • Verify user identity                                     │
│  • Check permissions (admin check if needed)                │
└───────────────────────┬─────────────────────────────────────┘
                        │
                   ┌────┴────┐
                   │ Valid?  │
                   └────┬────┘
                        │
                   ┌────┴────┐
                   │         │
                  Yes       No
                   │         │
                   │         ▼
                   │    ┌─────────────┐
                   │    │ Return 401  │
                   │    │ Unauthorized│
                   │    └─────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│              BUSINESS LOGIC                                  │
│  • Validate request data                                    │
│  • Apply business rules                                     │
│  • Prepare database operations                              │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ 5. Database Operation
                        │
                        ▼
┌─────────────────────────────────────────────────────────────┐
│         KV STORE ACCESS (kv_store.tsx)                      │
│  • kv.get(key) - Retrieve data                              │
│  • kv.set(key, value) - Store data                          │
│  • kv.del(key) - Delete data                                │
│  • kv.mget(keys) - Get multiple                             │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ 6. Database Query
                        │
                        ▼
┌─────────────────────────────────────────────────────────────┐
│         SUPABASE POSTGRESQL DATABASE                         │
│  • Execute SQL query                                        │
│  • Return result                                            │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ 7. Result
                        │
                        ▼
┌─────────────────────────────────────────────────────────────┐
│         RESPONSE PREPARATION                                 │
│  • Format data                                              │
│  • Create response object                                   │
│  • Add success/error status                                 │
│  • Log operation                                            │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ 8. HTTP Response
                        │    { success: true, data: {...} }
                        │
                        ▼
┌─────────────────────────────────────────────────────────────┐
│         API CLIENT RECEIVES RESPONSE                         │
│  • Check response status                                    │
│  • Parse JSON                                               │
│  • Handle errors                                            │
│  • Return data                                              │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ 9. Data
                        │
                        ▼
┌─────────────────────────────────────────────────────────────┐
│         COMPONENT UPDATES STATE                              │
│  • Update React state with new data                         │
│  • Trigger re-render                                        │
│  • Show toast notification                                  │
│  • Update UI elements                                       │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ 10. UI Update
                        │
                        ▼
┌─────────────────────────────────────────────────────────────┐
│         USER SEES UPDATED INTERFACE                          │
│  • Table/list updated                                       │
│  • Success message displayed                                │
│  • New data visible                                         │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎯 Feature Workflows

### Weather Data Flow

```
App Initialization
    │
    ▼
┌─────────────────────────────────┐
│ loadWeatherData() called        │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Try Auto-Location Detection     │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Call IP Geolocation API         │
│ Get: lat, lon, city             │
└──────────┬──────────────────────┘
           │
    ┌──────┴──────┐
    │ Success?    │
    └──────┬──────┘
           │
      ┌────┴────┐
      │         │
     Yes       No
      │         │
      │         ▼
      │    ┌─────────────────┐
      │    │ Use Default:    │
      │    │ Kabankalan City │
      │    └────────┬────────┘
      │             │
      └─────────────┘
                    │
                    ▼
┌─────────────────────────────────┐
│ Check Saved Location Override   │
│ GET /location                   │
└──────────┬──────────────────────┘
           │
    ┌──────┴──────┐
    │ Override?   │
    └──────┬──────┘
           │
      ┌────┴────┐
      │         │
     Yes       No
      │         │
      │         ▼
      │    Use auto-detected
      │         │
      └─────────┘
                │
                ▼
┌─────────────────────────────────┐
│ Call OpenWeatherMap API         │
│ With: lat, lon                  │
└──────────┬──────────────────────┘
           │
    ┌──────┴──────┐
    │ API Key?    │
    └──────┬──────┘
           │
      ┌────┴────┐
      │         │
     Yes       No
      │         │
      │         ▼
      │    ┌─────────────────┐
      │    │ Use Mock Data   │
      │    └────────┬────────┘
      │             │
      └─────────────┘
                    │
                    ▼
┌─────────────────────────────────┐
│ Parse Weather Data:             │
│ • Current temperature           │
│ • Conditions (sunny, rainy)     │
│ • Humidity, wind                │
│ • 5-day forecast                │
│ • Alerts (if any)               │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Update State & Display          │
│ • WeatherWidget shows data      │
│ • Dashboard shows summary       │
└─────────────────────────────────┘
```

### File Upload Flow (Photos & Avatars)

```
User Selects File
    │
    ▼
┌─────────────────────────────────┐
│ File Validation:                │
│ • Type: image/*                 │
│ • Size: < 2MB                   │
└──────────┬──────────────────────┘
           │
    ┌──────┴──────┐
    │ Valid?      │
    └──────┬──────┘
           │
      ┌────┴────┐
      │         │
     Yes       No
      │         │
      │         ▼
      │    ┌──────────┐
      │    │ Show     │
      │    │ Error    │
      │    └──────────┘
      │
      ▼
┌─────────────────────────────────┐
│ Read File with FileReader       │
│ Convert to Base64               │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Send to Server:                 │
│ POST /photos or /profile/avatar │
│ Body: { imageData, fileType }   │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Server Processing:              │
│ 1. Verify authentication        │
│ 2. Create bucket (if needed)    │
│ 3. Convert base64 to binary     │
│ 4. Generate unique filename     │
│ 5. Upload to Supabase Storage   │
│ 6. Get public URL               │
│ 7. Save URL to database         │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Return Public URL               │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│ Frontend Updates:               │
│ • Display uploaded image        │
│ • Update state                  │
│ • Show success message          │
└─────────────────────────────────┘
```

---

## 🔄 State Management

### App-Level State

```typescript
// Primary State Variables in App.tsx

Authentication State:
├─ isAuthenticated: boolean
├─ accessToken: string | null
└─ userProfile: UserProfile | null

UI State:
├─ activeTab: string (current page)
├─ isMobileSidebarOpen: boolean
├─ isDarkMode: boolean
├─ isLoading: boolean
└─ isCheckingSession: boolean

Weather State:
├─ weatherData: WeatherData
└─ isWeatherLoading: boolean

Data State (All Arrays):
├─ crops: Crop[]
├─ harvests: Harvest[]
├─ budgetItems: BudgetItem[]
├─ volunteers: Volunteer[]
├─ tasks: Task[]
├─ polls: Poll[]
├─ feedbacks: Feedback[]
├─ photos: Photo[]
├─ updates: Update[]
└─ events: Event[]

Computed State:
├─ budgetSpent: number (calculated)
├─ totalCrops: number (crops.length)
├─ activePlots: number (filtered)
└─ upcomingHarvests: number (filtered)
```

### State Update Flow

```
User Action
    │
    ▼
┌─────────────────────┐
│ Event Handler       │
│ (onClick, onChange) │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ API Call            │
│ (utils/api.ts)      │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Server Processing   │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Response Received   │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Update State        │
│ setState(newValue)  │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ React Re-render     │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ UI Updates          │
└─────────────────────┘
```

---

## ⚠️ Error Handling

### Error Handling Strategy

```
┌─────────────────────────────────┐
│        Error Occurs             │
└──────────┬──────────────────────┘
           │
    ┌──────┴──────────┐
    │   Error Type?   │
    └──────┬──────────┘
           │
    ┌──────┴──────────────────────┐
    │                             │
    ▼                             ▼
┌────────────┐              ┌────────────┐
│ Network    │              │ Validation │
│ Error      │              │ Error      │
└─────┬──────┘              └─────┬──────┘
      │                           │
      ▼                           ▼
┌──────────────┐          ┌──────────────┐
│ Retry Logic  │          │ Show Field   │
│ or Fallback  │          │ Error        │
└─────┬────────┘          └─────┬────────┘
      │                         │
      └────────┬────────────────┘
               │
               ▼
┌─────────────────────────────────┐
│   Log to Console                │
│   console.error(...)            │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│   Show User-Friendly Message    │
│   toast.error(...)              │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│   Maintain App Stability        │
│   (Don't crash)                 │
└─────────────────────────────────┘
```

### Error Types & Responses

| Error Type | Detection | User Feedback | Recovery |
|------------|-----------|---------------|----------|
| **401 Unauthorized** | Invalid/expired token | "Session expired. Please log in again." | Redirect to login |
| **403 Forbidden** | Insufficient permissions | "You don't have permission to perform this action." | Stay on page |
| **404 Not Found** | Resource doesn't exist | "Item not found." | Refresh data |
| **400 Bad Request** | Invalid data | "Please check your input and try again." | Highlight fields |
| **500 Server Error** | Server failure | "Something went wrong. Please try again later." | Retry option |
| **Network Error** | No connection | "Connection lost. Check your internet." | Retry button |
| **Validation Error** | Client-side validation | Field-specific error messages | Highlight field |

---

## 📱 Responsive Behavior

### Screen Size Adaptation

```
┌────────────────────────────────────────────────────────┐
│                    SCREEN SIZE                         │
└───────────────┬────────────────────────────────────────┘
                │
        ┌───────┴────────┐
        │                │
        ▼                ▼
┌──────────────┐   ┌─────────────┐
│   Mobile     │   │  Desktop    │
│  (< 1024px)  │   │ (≥ 1024px)  │
└──────┬───────┘   └──────┬──────┘
       │                  │
       ▼                  ▼
┌──────────────┐   ┌─────────────┐
│ • Sidebar    │   │ • Sidebar   │
│   Hidden     │   │   Always    │
│              │   │   Visible   │
│ • Burger     │   │             │
│   Menu       │   │ • Full      │
│   Visible    │   │   Layout    │
│              │   │             │
│ • Single     │   │ • Grid      │
│   Column     │   │   Layouts   │
│   Layouts    │   │             │
│              │   │ • Side-by-  │
│ • Stacked    │   │   Side      │
│   Cards      │   │   Content   │
└──────────────┘   └─────────────┘
```

---

## 🔐 Security Considerations

### Security Flow

```
┌─────────────────────────────────────────────────────────┐
│                  SECURITY LAYERS                        │
└─────────────────────────────────────────────────────────┘

Layer 1: Client-Side
├─ Input Validation (prevent injection)
├─ XSS Protection (sanitize input)
└─ HTTPS Only (secure transmission)

Layer 2: API Gateway
├─ CORS (allowed origins)
├─ Rate Limiting (prevent abuse)
└─ Request Size Limits

Layer 3: Authentication
├─ Bearer Token Verification
├─ Session Management
└─ Token Expiration

Layer 4: Authorization
├─ Role-Based Access Control
├─ Resource Ownership Check
└─ Admin Permission Verification

Layer 5: Database
├─ Parameterized Queries (prevent SQL injection)
├─ Data Validation
└─ Access Control

Layer 6: Storage
├─ File Type Validation
├─ Size Restrictions
└─ Virus Scanning (recommended)
```

### Sensitive Data Handling

```
Environment Variables:
├─ SUPABASE_SERVICE_ROLE_KEY
│  └─ NEVER sent to client
│  └─ Only used server-side
│
├─ SUPABASE_ANON_KEY
│  └─ Safe for client use
│  └─ Limited permissions
│
└─ API Keys
   └─ Server-side only
   └─ Not exposed in frontend
```

---

## 📊 Performance Optimization

### Data Loading Strategy

```
App Mount
    │
    ▼
┌─────────────────────┐
│ Check Session       │
│ (Immediate)         │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Load Critical Data  │
│ • User Profile      │
│ (Blocking)          │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Show Dashboard      │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Load Dashboard Data │
│ • Crops             │
│ • Harvests          │
│ • Budget            │
│ (Parallel)          │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Lazy Load Tabs      │
│ Load data when      │
│ tab is clicked      │
└─────────────────────┘
```

---

## 🎯 Summary

The Plant n' Plan system follows a modern three-tier architecture with clear separation of concerns:

1. **Frontend (React)** - User interface and interaction
2. **Backend (Supabase Edge Functions)** - Business logic and data processing
3. **Database (PostgreSQL + Storage)** - Data persistence

**Key Design Principles:**
- **Transparency First**: All community members see the same budget and activity data
- **Role-Based Access**: Admin features clearly separated but integrated
- **Mobile-First**: Responsive design for all screen sizes
- **Offline Resilience**: Graceful fallbacks for network issues
- **Type Safety**: TypeScript throughout for reliability
- **Real-Time Updates**: Immediate feedback for user actions

This workflow documentation should help developers understand how data flows through the system and how each feature operates.

---

*Last Updated: November 2, 2025*
